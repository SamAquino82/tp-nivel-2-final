﻿namespace Presentasion
{
    partial class FormDetalles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbldetalles = new System.Windows.Forms.Label();
            this.lbldetallenombre = new System.Windows.Forms.Label();
            this.lblcodigodetalle = new System.Windows.Forms.Label();
            this.lbldetallecategoria = new System.Windows.Forms.Label();
            this.lbldetaMarca = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblmarca = new System.Windows.Forms.Label();
            this.lbldescripcion = new System.Windows.Forms.Label();
            this.lblprecio = new System.Windows.Forms.Label();
            this.lblcategoria = new System.Windows.Forms.Label();
            this.lblcodigo = new System.Windows.Forms.Label();
            this.lblarticulo = new System.Windows.Forms.Label();
            this.ptxdetalles = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ptxdetalles)).BeginInit();
            this.SuspendLayout();
            // 
            // lbldetalles
            // 
            this.lbldetalles.AutoSize = true;
            this.lbldetalles.BackColor = System.Drawing.Color.Transparent;
            this.lbldetalles.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetalles.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbldetalles.Location = new System.Drawing.Point(10, 9);
            this.lbldetalles.Name = "lbldetalles";
            this.lbldetalles.Size = new System.Drawing.Size(97, 17);
            this.lbldetalles.TabIndex = 1;
            this.lbldetalles.Text = "DETALLES:";
            // 
            // lbldetallenombre
            // 
            this.lbldetallenombre.AutoSize = true;
            this.lbldetallenombre.BackColor = System.Drawing.Color.Transparent;
            this.lbldetallenombre.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetallenombre.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbldetallenombre.Location = new System.Drawing.Point(14, 36);
            this.lbldetallenombre.Name = "lbldetallenombre";
            this.lbldetallenombre.Size = new System.Drawing.Size(64, 17);
            this.lbldetallenombre.TabIndex = 2;
            this.lbldetallenombre.Text = "Articulo:";
            // 
            // lblcodigodetalle
            // 
            this.lblcodigodetalle.AutoSize = true;
            this.lblcodigodetalle.BackColor = System.Drawing.Color.Transparent;
            this.lblcodigodetalle.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcodigodetalle.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblcodigodetalle.Location = new System.Drawing.Point(12, 67);
            this.lblcodigodetalle.Name = "lblcodigodetalle";
            this.lblcodigodetalle.Size = new System.Drawing.Size(55, 17);
            this.lblcodigodetalle.TabIndex = 3;
            this.lblcodigodetalle.Text = "Codigo:";
            // 
            // lbldetallecategoria
            // 
            this.lbldetallecategoria.AutoSize = true;
            this.lbldetallecategoria.BackColor = System.Drawing.Color.Transparent;
            this.lbldetallecategoria.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetallecategoria.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbldetallecategoria.Location = new System.Drawing.Point(12, 98);
            this.lbldetallecategoria.Name = "lbldetallecategoria";
            this.lbldetallecategoria.Size = new System.Drawing.Size(73, 17);
            this.lbldetallecategoria.TabIndex = 4;
            this.lbldetallecategoria.Text = "Categoria:";
            // 
            // lbldetaMarca
            // 
            this.lbldetaMarca.AutoSize = true;
            this.lbldetaMarca.BackColor = System.Drawing.Color.Transparent;
            this.lbldetaMarca.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetaMarca.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbldetaMarca.Location = new System.Drawing.Point(12, 129);
            this.lbldetaMarca.Name = "lbldetaMarca";
            this.lbldetaMarca.Size = new System.Drawing.Size(54, 17);
            this.lbldetaMarca.TabIndex = 5;
            this.lbldetaMarca.Text = "Marca:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label6.Location = new System.Drawing.Point(12, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Precio:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label7.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label7.Location = new System.Drawing.Point(10, 217);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Sobre el Articulo:";
            // 
            // lblmarca
            // 
            this.lblmarca.AutoSize = true;
            this.lblmarca.BackColor = System.Drawing.Color.Transparent;
            this.lblmarca.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmarca.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblmarca.Location = new System.Drawing.Point(62, 129);
            this.lblmarca.Name = "lblmarca";
            this.lblmarca.Size = new System.Drawing.Size(45, 17);
            this.lblmarca.TabIndex = 8;
            this.lblmarca.Text = "label1";
            // 
            // lbldescripcion
            // 
            this.lbldescripcion.AutoSize = true;
            this.lbldescripcion.BackColor = System.Drawing.Color.Transparent;
            this.lbldescripcion.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescripcion.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.lbldescripcion.Location = new System.Drawing.Point(126, 217);
            this.lbldescripcion.Name = "lbldescripcion";
            this.lbldescripcion.Size = new System.Drawing.Size(47, 17);
            this.lbldescripcion.TabIndex = 9;
            this.lbldescripcion.Text = "label8";
            // 
            // lblprecio
            // 
            this.lblprecio.AutoSize = true;
            this.lblprecio.BackColor = System.Drawing.Color.Transparent;
            this.lblprecio.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprecio.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblprecio.Location = new System.Drawing.Point(62, 160);
            this.lblprecio.Name = "lblprecio";
            this.lblprecio.Size = new System.Drawing.Size(47, 17);
            this.lblprecio.TabIndex = 10;
            this.lblprecio.Text = "label9";
            // 
            // lblcategoria
            // 
            this.lblcategoria.AutoSize = true;
            this.lblcategoria.BackColor = System.Drawing.Color.Transparent;
            this.lblcategoria.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcategoria.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblcategoria.Location = new System.Drawing.Point(81, 98);
            this.lblcategoria.Name = "lblcategoria";
            this.lblcategoria.Size = new System.Drawing.Size(55, 17);
            this.lblcategoria.TabIndex = 11;
            this.lblcategoria.Text = "label10";
            // 
            // lblcodigo
            // 
            this.lblcodigo.AutoSize = true;
            this.lblcodigo.BackColor = System.Drawing.Color.Transparent;
            this.lblcodigo.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcodigo.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblcodigo.Location = new System.Drawing.Point(62, 67);
            this.lblcodigo.Name = "lblcodigo";
            this.lblcodigo.Size = new System.Drawing.Size(52, 17);
            this.lblcodigo.TabIndex = 12;
            this.lblcodigo.Text = "label11";
            // 
            // lblarticulo
            // 
            this.lblarticulo.AutoSize = true;
            this.lblarticulo.BackColor = System.Drawing.Color.Transparent;
            this.lblarticulo.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblarticulo.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblarticulo.Location = new System.Drawing.Point(72, 36);
            this.lblarticulo.Name = "lblarticulo";
            this.lblarticulo.Size = new System.Drawing.Size(55, 17);
            this.lblarticulo.TabIndex = 13;
            this.lblarticulo.Text = "label12";
            // 
            // ptxdetalles
            // 
            this.ptxdetalles.BackColor = System.Drawing.Color.Transparent;
            this.ptxdetalles.Location = new System.Drawing.Point(235, 12);
            this.ptxdetalles.Name = "ptxdetalles";
            this.ptxdetalles.Size = new System.Drawing.Size(205, 193);
            this.ptxdetalles.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptxdetalles.TabIndex = 0;
            this.ptxdetalles.TabStop = false;
            this.ptxdetalles.Click += new System.EventHandler(this.ptxdetalles_Click);
            // 
            // FormDetalles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Presentasion.Properties.Resources._77420df3f9e33db5b79ee25455d3340e;
            this.ClientSize = new System.Drawing.Size(452, 273);
            this.Controls.Add(this.lblarticulo);
            this.Controls.Add(this.lblcodigo);
            this.Controls.Add(this.lblcategoria);
            this.Controls.Add(this.lblprecio);
            this.Controls.Add(this.lbldescripcion);
            this.Controls.Add(this.lblmarca);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbldetaMarca);
            this.Controls.Add(this.lbldetallecategoria);
            this.Controls.Add(this.lblcodigodetalle);
            this.Controls.Add(this.lbldetallenombre);
            this.Controls.Add(this.lbldetalles);
            this.Controls.Add(this.ptxdetalles);
            this.Name = "FormDetalles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormDetalles";
            this.Load += new System.EventHandler(this.FormDetalles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptxdetalles)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ptxdetalles;
        private System.Windows.Forms.Label lbldetalles;
        private System.Windows.Forms.Label lbldetallenombre;
        private System.Windows.Forms.Label lblcodigodetalle;
        private System.Windows.Forms.Label lbldetallecategoria;
        private System.Windows.Forms.Label lbldetaMarca;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblmarca;
        private System.Windows.Forms.Label lbldescripcion;
        private System.Windows.Forms.Label lblprecio;
        private System.Windows.Forms.Label lblcategoria;
        private System.Windows.Forms.Label lblcodigo;
        private System.Windows.Forms.Label lblarticulo;
    }
}