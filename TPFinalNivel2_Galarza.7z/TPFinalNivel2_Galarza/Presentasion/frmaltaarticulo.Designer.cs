﻿namespace Presentasion
{
    partial class frmaltaarticulo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNOMBRE = new System.Windows.Forms.Label();
            this.lblcodigo = new System.Windows.Forms.Label();
            this.lblimagen = new System.Windows.Forms.Label();
            this.lbldescripcion = new System.Windows.Forms.Label();
            this.lblPRECIO = new System.Windows.Forms.Label();
            this.lblmarca = new System.Windows.Forms.Label();
            this.lblcategoria = new System.Windows.Forms.Label();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.txtcodigo = new System.Windows.Forms.TextBox();
            this.txtimagen = new System.Windows.Forms.TextBox();
            this.txtdescripcion = new System.Windows.Forms.TextBox();
            this.txtprecio = new System.Windows.Forms.TextBox();
            this.btnaceptar = new System.Windows.Forms.Button();
            this.btncancelar = new System.Windows.Forms.Button();
            this.cbxcategoria = new System.Windows.Forms.ComboBox();
            this.cbxmarca = new System.Windows.Forms.ComboBox();
            this.btnimagenlocal = new System.Windows.Forms.Button();
            this.pbxsub = new System.Windows.Forms.PictureBox();
            this.lblerrorprecio = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbxsub)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNOMBRE
            // 
            this.lblNOMBRE.AutoSize = true;
            this.lblNOMBRE.BackColor = System.Drawing.Color.Transparent;
            this.lblNOMBRE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblNOMBRE.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNOMBRE.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblNOMBRE.Location = new System.Drawing.Point(39, 61);
            this.lblNOMBRE.Name = "lblNOMBRE";
            this.lblNOMBRE.Size = new System.Drawing.Size(72, 14);
            this.lblNOMBRE.TabIndex = 0;
            this.lblNOMBRE.Text = "NOMBRE:";
            // 
            // lblcodigo
            // 
            this.lblcodigo.AutoSize = true;
            this.lblcodigo.BackColor = System.Drawing.Color.Transparent;
            this.lblcodigo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblcodigo.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcodigo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblcodigo.Location = new System.Drawing.Point(46, 26);
            this.lblcodigo.Name = "lblcodigo";
            this.lblcodigo.Size = new System.Drawing.Size(65, 14);
            this.lblcodigo.TabIndex = 1;
            this.lblcodigo.Text = "CODIGO:";
            // 
            // lblimagen
            // 
            this.lblimagen.AutoSize = true;
            this.lblimagen.BackColor = System.Drawing.Color.Transparent;
            this.lblimagen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblimagen.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblimagen.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblimagen.Location = new System.Drawing.Point(17, 139);
            this.lblimagen.Name = "lblimagen";
            this.lblimagen.Size = new System.Drawing.Size(94, 14);
            this.lblimagen.TabIndex = 2;
            this.lblimagen.Text = "URLIMAGEN:";
            // 
            // lbldescripcion
            // 
            this.lbldescripcion.AutoSize = true;
            this.lbldescripcion.BackColor = System.Drawing.Color.Transparent;
            this.lbldescripcion.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbldescripcion.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescripcion.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbldescripcion.Location = new System.Drawing.Point(6, 99);
            this.lbldescripcion.Name = "lbldescripcion";
            this.lbldescripcion.Size = new System.Drawing.Size(107, 14);
            this.lbldescripcion.TabIndex = 3;
            this.lbldescripcion.Text = "DESCRIPCION:";
            // 
            // lblPRECIO
            // 
            this.lblPRECIO.AutoSize = true;
            this.lblPRECIO.BackColor = System.Drawing.Color.Transparent;
            this.lblPRECIO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblPRECIO.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPRECIO.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblPRECIO.Location = new System.Drawing.Point(47, 177);
            this.lblPRECIO.Name = "lblPRECIO";
            this.lblPRECIO.Size = new System.Drawing.Size(64, 14);
            this.lblPRECIO.TabIndex = 4;
            this.lblPRECIO.Text = "PRECIO:";
            // 
            // lblmarca
            // 
            this.lblmarca.AutoSize = true;
            this.lblmarca.BackColor = System.Drawing.Color.Transparent;
            this.lblmarca.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblmarca.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmarca.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblmarca.Location = new System.Drawing.Point(54, 252);
            this.lblmarca.Name = "lblmarca";
            this.lblmarca.Size = new System.Drawing.Size(57, 14);
            this.lblmarca.TabIndex = 5;
            this.lblmarca.Text = "MARCA:";
            // 
            // lblcategoria
            // 
            this.lblcategoria.AutoSize = true;
            this.lblcategoria.BackColor = System.Drawing.Color.Transparent;
            this.lblcategoria.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblcategoria.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcategoria.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblcategoria.Location = new System.Drawing.Point(21, 217);
            this.lblcategoria.Name = "lblcategoria";
            this.lblcategoria.Size = new System.Drawing.Size(90, 14);
            this.lblcategoria.TabIndex = 6;
            this.lblcategoria.Text = "CATEGORIA:";
            // 
            // txtnombre
            // 
            this.txtnombre.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtnombre.Location = new System.Drawing.Point(112, 55);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(100, 20);
            this.txtnombre.TabIndex = 8;
            // 
            // txtcodigo
            // 
            this.txtcodigo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtcodigo.Location = new System.Drawing.Point(112, 20);
            this.txtcodigo.Name = "txtcodigo";
            this.txtcodigo.Size = new System.Drawing.Size(100, 20);
            this.txtcodigo.TabIndex = 9;
            // 
            // txtimagen
            // 
            this.txtimagen.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtimagen.Location = new System.Drawing.Point(112, 133);
            this.txtimagen.Name = "txtimagen";
            this.txtimagen.Size = new System.Drawing.Size(100, 20);
            this.txtimagen.TabIndex = 10;
            this.txtimagen.Leave += new System.EventHandler(this.txtimagen_Leave);
            // 
            // txtdescripcion
            // 
            this.txtdescripcion.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtdescripcion.Location = new System.Drawing.Point(112, 93);
            this.txtdescripcion.Name = "txtdescripcion";
            this.txtdescripcion.Size = new System.Drawing.Size(100, 20);
            this.txtdescripcion.TabIndex = 11;
            // 
            // txtprecio
            // 
            this.txtprecio.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtprecio.Location = new System.Drawing.Point(112, 171);
            this.txtprecio.Name = "txtprecio";
            this.txtprecio.Size = new System.Drawing.Size(100, 20);
            this.txtprecio.TabIndex = 12;
            this.txtprecio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprecio_KeyPress);
            // 
            // btnaceptar
            // 
            this.btnaceptar.BackColor = System.Drawing.SystemColors.Window;
            this.btnaceptar.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaceptar.Location = new System.Drawing.Point(285, 237);
            this.btnaceptar.Name = "btnaceptar";
            this.btnaceptar.Size = new System.Drawing.Size(89, 29);
            this.btnaceptar.TabIndex = 15;
            this.btnaceptar.Text = "Aceptar";
            this.btnaceptar.UseVisualStyleBackColor = false;
            this.btnaceptar.Click += new System.EventHandler(this.btnaceptar_Click);
            // 
            // btncancelar
            // 
            this.btncancelar.BackColor = System.Drawing.SystemColors.Window;
            this.btncancelar.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancelar.Location = new System.Drawing.Point(425, 237);
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(89, 29);
            this.btncancelar.TabIndex = 16;
            this.btncancelar.Text = "Cancelar";
            this.btncancelar.UseVisualStyleBackColor = false;
            this.btncancelar.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // cbxcategoria
            // 
            this.cbxcategoria.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cbxcategoria.FormattingEnabled = true;
            this.cbxcategoria.Location = new System.Drawing.Point(112, 210);
            this.cbxcategoria.Name = "cbxcategoria";
            this.cbxcategoria.Size = new System.Drawing.Size(100, 21);
            this.cbxcategoria.TabIndex = 17;
            // 
            // cbxmarca
            // 
            this.cbxmarca.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cbxmarca.FormattingEnabled = true;
            this.cbxmarca.Location = new System.Drawing.Point(112, 245);
            this.cbxmarca.Name = "cbxmarca";
            this.cbxmarca.Size = new System.Drawing.Size(100, 21);
            this.cbxmarca.TabIndex = 17;
            this.cbxmarca.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // btnimagenlocal
            // 
            this.btnimagenlocal.BackColor = System.Drawing.Color.AliceBlue;
            this.btnimagenlocal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnimagenlocal.Location = new System.Drawing.Point(218, 129);
            this.btnimagenlocal.Name = "btnimagenlocal";
            this.btnimagenlocal.Size = new System.Drawing.Size(30, 26);
            this.btnimagenlocal.TabIndex = 18;
            this.btnimagenlocal.Text = "+";
            this.btnimagenlocal.UseVisualStyleBackColor = false;
            this.btnimagenlocal.Click += new System.EventHandler(this.btnimagenlocal_Click);
            // 
            // pbxsub
            // 
            this.pbxsub.BackColor = System.Drawing.Color.Transparent;
            this.pbxsub.Location = new System.Drawing.Point(285, 20);
            this.pbxsub.Name = "pbxsub";
            this.pbxsub.Size = new System.Drawing.Size(229, 212);
            this.pbxsub.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxsub.TabIndex = 14;
            this.pbxsub.TabStop = false;
            // 
            // lblerrorprecio
            // 
            this.lblerrorprecio.AutoSize = true;
            this.lblerrorprecio.BackColor = System.Drawing.Color.Transparent;
            this.lblerrorprecio.ForeColor = System.Drawing.Color.Crimson;
            this.lblerrorprecio.Location = new System.Drawing.Point(215, 174);
            this.lblerrorprecio.Name = "lblerrorprecio";
            this.lblerrorprecio.Size = new System.Drawing.Size(0, 13);
            this.lblerrorprecio.TabIndex = 19;
            // 
            // frmaltaarticulo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Presentasion.Properties.Resources.unnamed;
            this.ClientSize = new System.Drawing.Size(526, 310);
            this.Controls.Add(this.lblerrorprecio);
            this.Controls.Add(this.btnimagenlocal);
            this.Controls.Add(this.cbxmarca);
            this.Controls.Add(this.cbxcategoria);
            this.Controls.Add(this.btncancelar);
            this.Controls.Add(this.btnaceptar);
            this.Controls.Add(this.pbxsub);
            this.Controls.Add(this.txtprecio);
            this.Controls.Add(this.txtdescripcion);
            this.Controls.Add(this.txtimagen);
            this.Controls.Add(this.txtcodigo);
            this.Controls.Add(this.txtnombre);
            this.Controls.Add(this.lblcategoria);
            this.Controls.Add(this.lblmarca);
            this.Controls.Add(this.lblPRECIO);
            this.Controls.Add(this.lbldescripcion);
            this.Controls.Add(this.lblimagen);
            this.Controls.Add(this.lblcodigo);
            this.Controls.Add(this.lblNOMBRE);
            this.Name = "frmaltaarticulo";
            this.Text = "frmaltaarticulo";
            this.Load += new System.EventHandler(this.frmaltaarticulo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxsub)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNOMBRE;
        private System.Windows.Forms.Label lblcodigo;
        private System.Windows.Forms.Label lblimagen;
        private System.Windows.Forms.Label lbldescripcion;
        private System.Windows.Forms.Label lblPRECIO;
        private System.Windows.Forms.Label lblmarca;
        private System.Windows.Forms.Label lblcategoria;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.TextBox txtcodigo;
        private System.Windows.Forms.TextBox txtimagen;
        private System.Windows.Forms.TextBox txtdescripcion;
        private System.Windows.Forms.TextBox txtprecio;
        private System.Windows.Forms.PictureBox pbxsub;
        private System.Windows.Forms.Button btnaceptar;
        private System.Windows.Forms.Button btncancelar;
        private System.Windows.Forms.ComboBox cbxcategoria;
        private System.Windows.Forms.ComboBox cbxmarca;
        private System.Windows.Forms.Button btnimagenlocal;
        private System.Windows.Forms.Label lblerrorprecio;
    }
}